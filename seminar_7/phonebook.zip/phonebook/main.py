"""
Создать телефонный справочник с возможностью импорта и экспорта данных в нескольких форматах.
"""
from controller import work_with_phonebook

if __name__ == "__main__":
    work_with_phonebook()
